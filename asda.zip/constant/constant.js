export const DayMap = {
  1: "mon",
  2: "tue",
  3: "wed",
  4: "thu",
  5: "fri",
  6: "sat",
  7: "sun",
};

export const MonthMap = {
  1: "January",
  2: "February",
  3: "March",
  4: "April",
  5: "May",
  6: "June",
  7: "July",
  8: "August",
  9: "September",
  10: "October",
  11: "November",
  12: "December",
};


export const MONTH_ORDER = [
  "JAN",
  "FEB",
  "MAR",
  "APR",
  "MAY",
  "JUN",
  "JUL",
  "AUG",
  "SEP",
  "OCT",
  "NOV",
  "DEC",
];


export const AVERAGE_PERIOD_DURATION = 5;
export const POST_MENSTRUAL_INTERVAL=10
// export const ENV = "dev" 
export const ENV = "prod" 

export const STATIC_TIME_FOR_SEND_NOTI_AT_TODAY = "06:00"