import User from "../../models/DoctorRegistration/DoctorRegistration.js";
import { nanoid } from "nanoid";
import axios from "axios";
import { generateToken } from "../../utils/token.js";
import { badRequestResponse, BD_CURRENT_DATE, BD_CURRENT_TIME, formatQuantityNumber, getBDCurrentDate, getBDCurrentTime, isOverlapping, isValid24h, normalizeDate, notFoundResponse, paginatedSuccessResponse, saveNotificationToDB, somethingWentWrong, successResponse, toMinutes } from "../../utils/utils.js";
import { DayMap, ENV, MonthMap, STATIC_TIME_FOR_SEND_NOTI_AT_TODAY } from "../../constant/constant.js";
import { ExceptionalDays, WeeklyDays } from "../../models/Schedule/doctorSchedule.js";
import { uploadToImageBB } from "../../config/uploadToImageBB.js";
import { Appointment } from "../../models/Schedule/userBooking.js";
import { Comment } from "../../models/Community/CommentModel.js";
import { createOrUpdateFCMToken, sendNotificationToUser } from "../../services/notificationService.js";
import bcrypt from "bcryptjs";
import Role from "../../models/RolePermission/RolePermission.js";
import Notification from "../../models/Notification/NotificationModel.js";
import UserFCMToken from "../../models/Notification/FCMModel.js";
import mongoose from "mongoose";

const generateUserId = (type) => {
  const id = nanoid(6).toUpperCase();
  return type === "doctor" ? `DOC-${id}` : `USR-${id}`;
};

const IMGBB_API_KEY = "61b3c68f784244053d3df422e1c17879";

const uploadToImgBB = async (file) => {
  try {
    const base64Image = file.buffer.toString("base64");

    const url = `https://api.imgbb.com/1/upload?key=${IMGBB_API_KEY}`;

    const formData = new URLSearchParams();
    formData.append("image", base64Image);

    const res = await axios.post(url, formData);

    return {
      url: res.data.data.url,
      delete_url: res.data.data.delete_url,
    };
  } catch (error) {
    console.error("ImgBB Upload Error:", error.response?.data || error.message);
    return null;
  }
};

export const registerUser = async (req, res) => {
  try {
    let {
      type, // 1 = doctor, 0 = user
      fullName,
      email,
      phoneNumber,
      doctorRegistrationNumber,
      isVerified,
      currentWorkplace,
      currentDesignation,
      aboutMe,
      qualifications,
      doctorIdCard,
      location,
      specialties,
      fcmToken,
    } = req.body;

    if (type === undefined || (Number(type) !== 0 && Number(type) !== 1)) {
      return badRequestResponse(res, "User type is required.", "User type is not found.");
    }

    if (typeof qualifications === "string") {
      qualifications = JSON.parse(qualifications);
    }

    if (typeof specialties === "string") {
      specialties = JSON.parse(specialties);
    }

    let conditions = [];

    // if (phoneNumber) {
    //   conditions.push({ phoneNumber });
    // }

    if (email) {
      conditions.push({ email });
    }

    // 🔍 check existing
    const existing = await User.findOne({
      $or: conditions,
    });

    if (existing && existing.email === email) {
      return res.status(200).json({
        success: false,
        message: "User already exists with this email" + (existing.type === 1 ? " as a doctor" : " as a user"),
      });
    }

    // 🔥 ROLE LOGIC (MAIN FIX)
    const isDoctor = Number(type) === 1 ? 1 : 0;
    const isUser = Number(type) === 1 ? 0 : 1;

    // 🔥 upload image
    let doctorIdCardData = {};

    // 🔥 generate userId
    const userId = generateUserId(type);

    // 🧠 create user
    const newUser = await User.create({
      userId,
      type: Number(type),
      fullName,
      email,
      phoneNumber: phoneNumber ? phoneNumber : null,
      doctorRegistrationNumber: doctorRegistrationNumber ? doctorRegistrationNumber : null,
      currentWorkplace: currentWorkplace ? currentWorkplace : null,
      currentDesignation: currentDesignation ? currentDesignation : null,
      aboutMe: aboutMe ? aboutMe : null,
      qualifications: qualifications ? qualifications : null,
      doctorIdCard: doctorIdCard ? doctorIdCard : null,
      isDoctor,
      isUser,
      location: location ? location : null,
      specialties: specialties ? specialties : null,
      isRemoved: false,
      isVerified: isVerified ? isVerified : false,
    });

    // 🔐 JWT token
    const token = generateToken(newUser);

    // 🎯 clean response (ONLY ONE FLAG SHOW)
    const responseUser = {
      _id: newUser._id,
      userId: newUser.userId,
      type: newUser.type,
      fullName: newUser.fullName,
      email: newUser.email,
      phoneNumber: newUser.phoneNumber || null,
      doctorRegistrationNumber: newUser.doctorRegistrationNumber || null,
      currentWorkplace: newUser.currentWorkplace || null,
      currentDesignation: newUser.currentDesignation || null,
      aboutMe: newUser.aboutMe || null,
      qualifications: newUser.qualifications || null,
      doctorIdCard: newUser.doctorIdCard || null,
      isVerified: newUser.isVerified || false,
      location: newUser.location || null,
      specialties: newUser.specialties || null,
      ...(Number(type) === 1 ? { isDoctor: 1 } : { isUser: 0 }),
    };

    const fcmTokenSaving = await createOrUpdateFCMToken({ fcmToken, userId: newUser.userId, email: newUser.email });
    // console.log("🚀 ~ doctorRegistration.js:153 ~ registerUser ~ fcmTokenSaving:", fcmTokenSaving);

    return res.status(200).json({
      success: true,
      message: "Registration successful",
      token,
      data: responseUser,
    });
  } catch (error) {
    console.error(error);

    return res.status(200).json({
      success: false,
      message: error.message,
    });
  }
};

export const loginUser = async (req, res) => {
  try {
    const { email, fcmToken } = req.body;

    // 🔍 check user by email only
    const user = await User.findOne({ email });

    if (fcmToken) {
      const fcmTokenSaving = await createOrUpdateFCMToken({ fcmToken, email, user: user.userId });
    }

    // ❌ not found
    if (!user) {
      return res.status(200).json({
        success: false,
        message: "No account found with this email",
      });
    }

    // 🔐 generate token
    const token = generateToken(user);

    return res.status(200).json({
      success: true,
      message: "Login successful",
      token,
      data: user,
    });
  } catch (error) {
    return res.status(200).json({
      success: false,
      message: error.message,
    });
  }
};

export const loginadmin = async (req, res) => {
  try {
    const { identifier, password } = req.body;

    const user = await User.findOne({
      phoneNumber: identifier.trim(),
      newpartroles: "SUPERadmin",
    }).lean();

    // ❌ no user
    if (!user) {
      return res.status(200).json({
        success: false,
        message: "Admin account not found",
      });
    }

    // compare
    const dbPassword = user.password?.trim();
    const enteredPassword = password?.trim();

    if (dbPassword !== enteredPassword) {
      return res.status(200).json({
        success: false,
        message: "Incorrect password",
      });
    }

    // token
    const token = generateToken(user);

    return res.status(200).json({
      success: true,
      message: "Admin login successful",
      token,
      user,
    });
  } catch (error) {
    console.log(error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const saveFCMToken = async (req, res) => {
  try {
    const { fcmToken } = req.body;
    const { userId } = req.params;
    const user = await User.findOne({ userId });

    if (!user) {
      return notFoundResponse(res, "User not found", "Requested user does not exist.");
    }

    const fcmTokenSaving = await createOrUpdateFCMToken({ fcmToken, email: user.email, userId });
    return successResponse(res, fcmTokenSaving, "FCM Token saved successfully", "FCM Token saved successfully.");
  } catch (error) {
    console.error("SAVE_FCM_TOKEN_ERROR:", error);
    somethingWentWrong(res, "Unable to save FCM Token", "Unable to save FCM Token");
  }
};

export const updateProfile = async (req, res) => {
  let { dateOfBirth, phoneNumber, isVerified, type, aboutMe, doctorRegistrationNumber, currentWorkplace, currentDesignation, qualifications, doctorIdCard, location, specialties } = req.body;
  console.log("🚀 ~ doctorRegistration.js:275 ~ updateProfile ~ req.body:", req.body);

  const { userId } = req.params;

  try {
    /* =========================
       VALIDATE TYPE
    ========================= */

    if (Number(type) === 0) {
      return badRequestResponse(res, "Only doctors can update doctor profile.", "Profile update failed: User is not a doctor.");
    }

    /* =========================
       PARSE QUALIFICATIONS
    ========================= */

    if (typeof qualifications === "string") {
      qualifications = JSON.parse(qualifications);
    }

    if (qualifications !== undefined && !Array.isArray(qualifications)) {
      return notFoundResponse(res, "Qualifications information is required", "Profile update failed: Qualifications data is missing.");
    }

    /* =========================
       REQUIRED FIELD
    ========================= */

    if (!doctorRegistrationNumber) {
      return notFoundResponse(res, "Doctor registration number is required", "Profile update failed: Doctor registration number is missing.");
    }

    const updateData = {};

    /* =========================
       COMMON FIELD
    ========================= */

    if (aboutMe !== undefined) {
      updateData.aboutMe = aboutMe;
    }

    /* =========================
       DOCTOR FIELDS
    ========================= */

    if (doctorRegistrationNumber !== undefined) {
      updateData.doctorRegistrationNumber = doctorRegistrationNumber;
    }

    if (currentWorkplace !== undefined) {
      updateData.currentWorkplace = currentWorkplace;
    }

    if (currentDesignation !== undefined) {
      updateData.currentDesignation = currentDesignation;
    }

    if (qualifications !== undefined) {
      updateData.qualifications = qualifications;
    }

    if (location !== undefined) {
      updateData.location = location;
    }

    /* =========================
       PHONE VALIDATION
    ========================= */

    if (phoneNumber !== undefined) {
      const bdPhoneRegex = /^(\+8801|8801|01)[3-9]\d{8}$/;

      if (!bdPhoneRegex.test(phoneNumber)) {
        return badRequestResponse(res, "Invalid Phone number.", "Profile update failed: Phone number format is invalid.");
      }

      updateData.phoneNumber = phoneNumber;
    }

    /* =========================
       VERIFIED
    ========================= */

    if (isVerified === true || isVerified === "true") {
      updateData.isVerified = true;
    }

    if (specialties !== undefined) {
      updateData.specialties = JSON.parse(specialties);
    }

    /* =========================
       IMAGE UPLOAD
    ========================= */

    if (req.files?.doctorIdCard?.[0]) {
      const uploadedDoctorCard = await uploadToImageBB(req.files.doctorIdCard[0]);

      updateData.doctorIdCard = {
        url: uploadedDoctorCard,
        deleteUrl: null,
      };
    }

    if (dateOfBirth !== undefined) {
      updateData.dateOfBirth = dateOfBirth;
    }

    if (req.files?.profilePhoto?.[0]) {
      const uploadedProfilePhoto = await uploadToImageBB(req.files.profilePhoto[0]);

      updateData.profilePhoto = uploadedProfilePhoto;
    }

    /* =========================
       UPDATE USER
    ========================= */

    const updatedUser = await User.findOneAndUpdate(
      { userId },
      {
        $set: updateData,
      },
      {
        new: true,
        runValidators: true,
      },
    );

    return successResponse(res, updatedUser, "Profile updated successfully.", "Doctor profile updated successfully.");
  } catch (error) {
    console.error(error);

    return somethingWentWrong(res, error, "Failed to update profile", "Profile update error");
  }
};

export const getProfile = async (req, res) => {
  const { userId } = req.params;

  try {
    const user = await User.findOne({ userId, $or: [{ isRemoved: false }, { isRemoved: { $exists: false } }] }).lean();

    if (user) {
      return successResponse(res, user, "Profile information retrieved successfully", "Get profile information successful.");
    } else {
      return notFoundResponse(res, "User not found.", "Get profile failed: User not found.");
    }
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Failed to get profile information.", "Get profile error");
  }
};

export const getAllDoctors = async (req, res) => {
  try {
    const doctors = await User.find({
      isDoctor: 1,
      $or: [{ isRemoved: false }, { isRemoved: { $exists: false } }],
    })

      .select("location currentWorkplace specialties qualifications fullName currentDesignation doctorRegistrationNumber  email isVerified currentWorkplace userId createdAt updatedAt isRemoved ")
      .lean();

    if (!doctors.length) {
      return notFoundResponse(res, "No doctors found.", "Get all doctors failed: empty result.");
    }

    return successResponse(res, doctors, "Doctors retrieved successfully", "Get all doctors successful.");
  } catch (error) {
    console.error(error);

    return somethingWentWrong(res, error, "Failed to get doctors.", "Get all doctors error");
  }
};

export const getAllDoctorByAdmin = async (req, res) => {
  try {
    const { page = 1, limit = 10, sortBy = "createdAt", sortOrder = "desc" } = req.body;

    const skip = (page - 1) * limit;

    const filter = {
      isDoctor: 1,
      $or: [{ isRemoved: false }, { isRemoved: { $exists: false } }],
    };

    const allowedSortFields = ["fullName", "email", "createdAt", "updatedAt", "score", "isVerified", "doctorRegistrationNumber", "currentWorkplace", "currentDesignation"];

    const sort = {};

    if (allowedSortFields.includes(sortBy)) {
      sort[sortBy] = sortOrder === "asc" ? 1 : -1;
    } else {
      sort.createdAt = -1;
    }

    const [doctors, total] = await Promise.all([User.find(filter).select("fullName score profilePhoto currentDesignation doctorRegistrationNumber email isVerified currentWorkplace userId createdAt updatedAt isRemoved type location").sort(sort).skip(skip).limit(limit).lean(), User.countDocuments(filter)]);

    if (!doctors.length) {
      return notFoundResponse(res, "No doctors found.", "Get all doctors failed: empty result.");
    }

    return paginatedSuccessResponse(res, doctors, page, limit, total, "Doctors retrieved successfully", "Get all doctors successfully.");
  } catch (error) {
    console.error(error);

    return somethingWentWrong(res, error, "Failed to get doctors.", "Get all doctors error");
  }
};

export const approveSingleDoctor = async (req, res) => {
  const { userId } = req.params;

  try {
    const doctor = await User.findOne({ userId, isRemoved: false });

    if (!doctor || doctor.isDoctor !== 1) {
      return notFoundResponse(res, "This user is not a", `Update failed: Doctor not found with userId ${userId}`);
    }

    doctor.isVerified = true;

    await doctor.save();
    const obj = { userId, title: "Account Verified", body: "Your account has been verified successfully.", type: "accountVerified" };

    const notification = await sendNotificationToUser(obj);
    const notiSave = await saveNotificationToDB({ userId, title: "Account Verified", body: "Your account has been verified successfully.", type: "accountVerified", notificationSendTime: BD_CURRENT_TIME, notificationSendDate: BD_CURRENT_DATE });

    return successResponse(res, doctor, "Doctor verified successfully", `Doctor verified: ${userId}`);
  } catch (error) {
    console.error(error);

    return somethingWentWrong(res, error, "Failed to verify doctor.", "Verify doctor error");
  }
};

export const deleteDoctor = async (req, res) => {
  const { userId } = req.params;

  try {
    const doctor = await User.findOne({ userId });

    if (!doctor || doctor.isDoctor !== 1) {
      return notFoundResponse(res, "Doctor not found.", `Delete failed: Doctor not found with userId ${userId}`);
    }

    // Soft delete
    doctor.isRemoved = true;

    await doctor.save();

    return successResponse(res, doctor, "Doctor removed successfully.", `Doctor marked as removed: ${userId}`);
  } catch (error) {
    console.error(error);

    return somethingWentWrong(res, error, "Failed to remove doctor.", "Delete doctor error");
  }
};

export const getDoctorByRegistrationNumber = async (req, res) => {
  const { doctorRegistrationNumber } = req.params;

  try {
    const doctor = await User.findOne({
      doctorRegistrationNumber,
      isDoctor: 1,
      $or: [{ isRemoved: false }, { isRemoved: { $exists: false } }],
    }).lean();

    if (!doctor) {
      return notFoundResponse(res, "Doctor not found with this registration number.", `Get doctor failed: No doctor found with registration number ${doctorRegistrationNumber}`);
    }

    return successResponse(res, doctor, "Doctor retrieved successfully", `Get doctor by registration number successful: ${doctorRegistrationNumber}`);
  } catch (error) {
    console.error(error);

    return somethingWentWrong(res, error, "Failed to get doctor information.", "Get doctor by registration number error");
  }
};

export const searchDoctors = async (req, res) => {
  const { query } = req.params;

  try {
    const doctors = await User.find({
      type: 1,
      $and: [
        {
          $or: [{ fullName: { $regex: query, $options: "i" } }, { phoneNumber: { $regex: query, $options: "i" } }, { doctorRegistrationNumber: { $regex: query, $options: "i" } }, { currentWorkplace: { $regex: query, $options: "i" } }, { email: { $regex: query, $options: "i" } }],
        },
        {
          $or: [{ isRemoved: false }, { isRemoved: { $exists: false } }],
        },
      ],
    })
      .select("location profilePhoto currentWorkplace specialties qualifications fullName currentDesignation doctorRegistrationNumber  email isVerified currentWorkplace userId createdAt updatedAt isRemoved")
      .lean();

    if (!doctors.length) {
      return notFoundResponse(res, "No doctors found.", "Search doctors failed: empty result.");
    }

    return successResponse(res, doctors, "Doctors retrieved successfully", "Search doctors successful.");
  } catch (error) {
    console.error(error);

    return somethingWentWrong(res, error, "Failed to search doctors.", "Search doctors error");
  }
};

export const addSchedule = async (req, res) => {
  const { userId } = req.params;
  const { startTime, endTime, maxAppointments = 20, day } = req.body;

  const dayNumber = Number(day);
  const dayKey = DayMap[dayNumber];

  // 1. Validate day
  if (!dayKey) {
    return res.status(400).json({ success: false, message: "Invalid day." });
  }

  // 2. Validate time presence
  if (!startTime || !endTime) {
    return res.status(400).json({
      success: false,
      message: "Start time and end time are required.",
    });
  }

  // 3. Validate 24h format
  if (!isValid24h(startTime) || !isValid24h(endTime)) {
    return res.status(400).json({
      success: false,
      message: "Times must be in 24-hour format HH:MM (e.g. 09:00, 17:30).",
    });
  }

  // 4. Validate range
  if (toMinutes(startTime) >= toMinutes(endTime)) {
    return res.status(400).json({
      success: false,
      message: "Start time must be before end time.",
    });
  }

  const schedule = { startTime, endTime, maxAppointments };

  try {
    // 5. Overlap check
    const existing = await WeeklyDays.findOne({ doctorUserId: userId });

    if (existing?.[dayKey]?.time?.length > 0) {
      if (isOverlapping(startTime, endTime, existing[dayKey].time)) {
        return res.status(400).json({
          success: false,
          message: "Time slot overlaps with an existing schedule.",
        });
      }
    }

    // 6. Upsert
    const updated = await WeeklyDays.findOneAndUpdate(
      { doctorUserId: userId },
      {
        $setOnInsert: { doctorUserId: userId },
        $set: { [`${dayKey}.isEnable`]: true },
        $push: { [`${dayKey}.time`]: schedule },
      },
      { new: true, upsert: true, runValidators: true },
    );

    return res.status(200).json({
      success: true,
      data: updated,
      message: "Schedule added successfully",
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      success: false,
      message: "Failed to add schedule",
    });
  }
};

export const removeSchedule = async (req, res) => {
  const { doctorUserId, day, startTime, endTime, maxAppointments = 20 } = req.body;

  const dayNumber = Number(day);
  const dayKey = DayMap[dayNumber];

  // 1. Validate day
  if (!dayKey) {
    return res.status(400).json({
      success: false,
      message: "Invalid day",
    });
  }

  try {
    // 2. Check if doctor schedule exists
    const doctorSchedule = await WeeklyDays.findOne({
      doctorUserId,
    });

    if (!doctorSchedule) {
      return res.status(404).json({
        success: false,
        message: "Schedule not found",
      });
    }

    const removingSlot = {
      startTime,
      endTime,
    };

    // 3. Remove exact slot
    let updated = await WeeklyDays.findOneAndUpdate(
      {
        doctorUserId,
      },
      {
        $pull: {
          [`${dayKey}.time`]: removingSlot,
        },
      },
      {
        new: true,
      },
    );

    // 4. Optional: disable day if no slots left
    const remainingSlots = updated?.[dayKey]?.time?.length || 0;

    const ifSlotExist = await WeeklyDays.findOne({
      doctorUserId,
      [`${dayKey}.isEnable`]: true,
    });
    console.log("🚀 ~ doctorRegistration.js:700 ~ removeSchedule ~ ifSlotExist:", remainingSlots);
    return res.send({ ifSlotExist });

    if (!ifSlotExist) {
      return res.status(404).json({
        success: false,
        message: "Schedule slot not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: updated,
      message: "Schedule removed successfully",
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message: "Failed to remove schedule",
    });
  }
};

export const enableDisableWeekDay = async (req, res) => {
  const { day } = req.body;
  const { userId } = req.params;
  const doctorUserId = userId;

  const dayNumber = Number(day);
  const dayKey = DayMap[dayNumber];

  // 1. Validate day
  if (!dayKey) {
    return res.status(400).json({
      success: false,
      message: "Invalid day",
    });
  }

  try {
    // 2. Check if doctor schedule exists
    const doctorSchedule = await WeeklyDays.findOne({
      doctorUserId,
    });

    if (!doctorSchedule) {
      return res.status(404).json({
        success: false,
        message: "Schedule not found",
      });
    }

    // 3. Disable day
    const updated = await WeeklyDays.findOneAndUpdate(
      {
        doctorUserId,
      },
      [
        {
          $set: {
            [`${dayKey}.isEnable`]: { $not: [`$${dayKey}.isEnable`] },
          },
        },
      ],
      {
        new: true,
      },
    );

    return res.status(200).json({
      success: true,
      data: updated,
      message: "Weekday disabled successfully",
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      success: false,
      message: "Failed to disable weekday",
    });
  }
};

export const getDailySchedule = async (req, res) => {
  const { userId } = req.params;
  const { date } = req.body;
  const day = new Date(date).getDay();

  const dateStringWithoutTime = date.split("T")[0];

  try {
    const dayNumber = Number(day);
    const dayKey = DayMap[dayNumber];

    if (!dayKey) {
      return res.status(400).json({
        success: false,
        message: "Invalid day",
      });
    }

    const dailySchedule = await ExceptionalDays.findOne({
      doctorUserId: userId,
      date: dateStringWithoutTime, // Matches the target date record specifically
    });

    if (dailySchedule) {
      return successResponse(res, dailySchedule, "Schedule fetched successfully.", "Schedule fetched successfully.");
    }

    const weeklySchedule = await WeeklyDays.findOne(
      { doctorUserId: userId },
      { [dayKey]: 1, doctorUserId: 1 }, // Projection: 1 means include, exclude everything else
    );

    const daySchedule = weeklySchedule[dayKey];

    if (daySchedule) {
      return successResponse(res, daySchedule, "Schedule fetched successfully.", "Schedule fetched successfully.");
    }

    return res.status(404).json({
      success: false,
      message: "Schedule not found",
    });
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Failed to fetch schedule");
  }
};

export const addExceptionalSchedule = async (req, res) => {
  const { userId } = req.params;
  const { date, maxAppointments = 20 } = req.body;

  // Convert incoming 12-hour format to 24-hour format
  const time = req.body.time?.map((slot) => {
    let [startTime, startPeriod] = slot.startTime.split(" ");
    let [startHour, startMinute] = startTime.split(":").map(Number);

    if (startPeriod === "PM" && startHour !== 12) startHour += 12;
    if (startPeriod === "AM" && startHour === 12) startHour = 0;

    let [endTime, endPeriod] = slot.endTime.split(" ");
    let [endHour, endMinute] = endTime.split(":").map(Number);

    if (endPeriod === "PM" && endHour !== 12) endHour += 12;
    if (endPeriod === "AM" && endHour === 12) endHour = 0;

    return {
      ...slot,
      startTime: `${String(startHour).padStart(2, "0")}:${String(startMinute).padStart(2, "0")}`,
      endTime: `${String(endHour).padStart(2, "0")}:${String(endMinute).padStart(2, "0")}`,
    };
  });

  // 1. Validate required fields
  if (!date || !time || !Array.isArray(time)) {
    return res.status(400).json({
      success: false,
      message: "Date and Time array are required.",
    });
  }

  // 2. Validate each slot
  for (const slot of time) {
    const { startTime, endTime } = slot;

    if (!startTime || !endTime) {
      return res.status(400).json({
        success: false,
        message: "Each slot must have start time and end time.",
      });
    }

    if (!isValid24h(startTime) || !isValid24h(endTime)) {
      return res.status(400).json({
        success: false,
        message: `Invalid 24h format in slot: ${startTime} - ${endTime}`,
      });
    }

    if (toMinutes(startTime) >= toMinutes(endTime)) {
      return res.status(400).json({
        success: false,
        message: `Start time must be before end time in slot: ${startTime} - ${endTime}`,
      });
    }
  }

  // 3. Check overlap within the request itself
  for (let i = 0; i < time.length; i++) {
    for (let j = i + 1; j < time.length; j++) {
      const a = time[i];
      const b = time[j];

      if (toMinutes(a.startTime) < toMinutes(b.endTime) && toMinutes(a.endTime) > toMinutes(b.startTime)) {
        return res.status(400).json({
          success: false,
          message: `Slots overlap each other: ${a.startTime}-${a.endTime} and ${b.startTime}-${b.endTime}`,
        });
      }
    }
  }

  // 4. Validate date
  const parsedDate = new Date(date);

  if (isNaN(parsedDate.getTime())) {
    return res.status(400).json({
      success: false,
      message: "Invalid date format.",
    });
  }

  const dateKey = parsedDate.toISOString().split("T")[0];
  const monthName = MonthMap[parsedDate.getMonth() + 1];

  // Normalize slots
  const newSlots = time.map((slot) => ({
    startTime: slot.startTime,
    endTime: slot.endTime,
    maxAppointments: slot.maxAppointments ?? maxAppointments,
  }));

  try {
    // Find existing exceptional day
    const existing = await ExceptionalDays.findOne({
      doctorUserId: userId,
      date: dateKey,
    });

    if (existing) {
      // Check overlap with existing slots
      for (const slot of newSlots) {
        if (isOverlapping(slot.startTime, slot.endTime, existing.time)) {
          return res.status(409).json({
            success: false,
            message: `Slot ${slot.startTime}-${slot.endTime} overlaps with an existing slot.`,
          });
        }
      }

      // Append slots
      const updated = await ExceptionalDays.findOneAndUpdate(
        {
          doctorUserId: userId,
          date: dateKey,
        },
        {
          $push: {
            time: {
              $each: newSlots,
            },
          },
          $set: {
            isEnable: true,
          },
        },
        {
          new: true,
        },
      );

      return res.status(200).json({
        success: true,
        data: updated,
        message: `Slots added to existing exceptional day (${monthName})`,
      });
    }

    // Create new exceptional day
    const created = await ExceptionalDays.create({
      doctorUserId: userId,
      date: dateKey,
      isEnable: true,
      time: newSlots,
    });

    return res.status(201).json({
      success: true,
      data: created,
      message: `Exceptional schedule created for ${monthName}`,
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message: "Failed to add exceptional schedule.",
    });
  }
};

export const removeExceptionalDay = async (req, res) => {
  const { userId } = req.params;
  const { date } = req.body;
  const formattedDate = new Date(date).toISOString().split("T")[0];

  try {
    const deleted = await ExceptionalDays.findOneAndDelete({ doctorUserId: userId, date: formattedDate });
    return res.status(200).json({
      success: true,
      data: deleted,
      message: "Exceptional day removed",
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Failed to remove exceptional day",
    });
  }
};

export const setDoctorScore = async (req, res) => {
  const { userId } = req.params;
  const { score, isVerified } = req.body;
  if (!isVerified) {
    return badRequestResponse(res, "Doctor is not verified", "Doctor is not verified");
  }
  try {
    const updated = await User.findOneAndUpdate({ userId, type: 1 }, { score }, { new: true });
    return successResponse(res, updated, "Score updated successfully", "Score updated successfully");
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Failed to update score");
  }
};

export const getDoctorMonthlySchedule = async (req, res) => {
  const { userId } = req.params;
  const month = Number(req.body.month);

  try {
    if (!MonthMap[month]) {
      return badRequestResponse(res, "Invalid month", "Month must be between 1 and 12");
    }

    const weekDay = await WeeklyDays.findOne({
      doctorUserId: userId,
    });

    const exceptionalDay = await ExceptionalDays.find({
      doctorUserId: userId,
    });

    const filteredExceptionalDays = exceptionalDay.filter((item) => {
      return new Date(item.date).getMonth() + 1 === month;
    });

    return successResponse(
      res,
      {
        weekDay,
        exceptionalDay: filteredExceptionalDays,
      },
      "Schedule fetched successfully",
      "Schedule fetched successfully",
    );
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Failed to fetch schedule");
  }
};

// export const getConfirmedAppointments = async (req, res) => {
//   const { userId } = req.params;
//   const { page = 1, limit = 10 } = req.body;

//   const parsedPage = Math.max(parseInt(page, 10), 1);
//   const parsedLimit = Math.max(parseInt(limit, 10), 1);

//   const filter = {
//     doctorUserId: userId,
//     status: "confirmed",
//   };

//   try {
//     const [appointments, totalAppointments] = await Promise.all([
//       Appointment.find(filter)
//         .sort({
//           appointmentDate: -1, // Latest date first
//           appointmentTime: -1, // Latest time first within the same date
//         })
//         .skip((parsedPage - 1) * parsedLimit)
//         .limit(parsedLimit),

//       Appointment.countDocuments(filter),
//     ]);

//     return successResponse(
//       res,
//       {
//         appointments,
//         pagination: {
//           page: parsedPage,
//           limit: parsedLimit,
//           totalAppointments,
//           totalPages: Math.ceil(totalAppointments / parsedLimit),
//           hasNextPage: parsedPage * parsedLimit < totalAppointments,
//           hasPreviousPage: parsedPage > 1,
//         },
//       },
//       "Appointments retrieved successfully.",
//       "Get appointments successful.",
//     );
//   } catch (error) {
//     console.error(error);
//     return somethingWentWrong(res, error, "Something went wrong.");
//   }
// };

export const getDailyAppointments = async (req, res) => {
  const { userId } = req.params;
  const { date } = req.body;

  const formattedDate = normalizeDate(date);

  if (!formattedDate) {
    return res.status(400).json({
      success: false,
      message: "Invalid date format.",
    });
  }

  try {
    const appointments = await Appointment.find({
      doctorUserId: userId,
      appointmentDate: formattedDate, // assuming your schema uses appointmentDate
    });

    return successResponse(res, appointments, "Appointments retrieved successfully.", "Get appointments successful.");
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.");
  }
};

export const getConfirmedAppointments = async (req, res) => {
  const { userId } = req.params;
  const { page = 1, limit = 10, date } = req.body;

  const parsedPage = Math.max(parseInt(page, 10), 1);
  const parsedLimit = Math.max(parseInt(limit, 10), 1);

  const filter = {
    doctorUserId: userId,
    status: "confirmed",
  };

  // Filter by requested date
  if (date) {
    filter.appointmentDate = new Date(date).toISOString().split("T")[0];
  }

  try {
    const [appointments, totalAppointments] = await Promise.all([
      Appointment.find(filter)
        .sort({
          appointmentDate: -1,
          startTime: -1,
        })
        .skip((parsedPage - 1) * parsedLimit)
        .limit(parsedLimit),

      Appointment.countDocuments(filter),
    ]);

    // ---------------------------------------
    // Fetch all users in one query
    // ---------------------------------------

    const ids = [...new Set(appointments.flatMap((appointment) => [appointment.userId, appointment.doctorUserId]))];

    const users = await User.find({
      userId: { $in: ids },
    }).lean();

    // Create lookup table
    const userMap = {};

    users.forEach((user) => {
      userMap[user.userId] = user;
    });

    // Attach doctor & patient data
    const appointmentsWithUsers = appointments.map((appointment) => ({
      ...appointment.toObject(),
      user: userMap[appointment.userId] || null,
      doctor: userMap[appointment.doctorUserId] || null,
    }));

    return successResponse(
      res,
      {
        appointments: appointmentsWithUsers,
        pagination: {
          page: parsedPage,
          limit: parsedLimit,
          totalAppointments,
          totalPages: Math.ceil(totalAppointments / parsedLimit),
          hasNextPage: parsedPage * parsedLimit < totalAppointments,
          hasPreviousPage: parsedPage > 1,
        },
      },
      "Appointments retrieved successfully.",
      "Get appointments successful.",
    );
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.");
  }
};

export const getCompletedAppointments = async (req, res) => {
  const { userId } = req.params;
  const { page = 1, limit = 10 } = req.body;

  const parsedPage = Math.max(parseInt(page, 10), 1);
  const parsedLimit = Math.max(parseInt(limit, 10), 1);

  const filter = {
    doctorUserId: userId,
    status: "completed",
  };

  try {
    const [appointments, totalAppointments] = await Promise.all([
      Appointment.find(filter)
        .sort({
          appointmentDate: -1, // Latest date first
          appointmentTime: -1, // Latest time first within the same date
        })
        .skip((parsedPage - 1) * parsedLimit)
        .limit(parsedLimit),

      Appointment.countDocuments(filter),
    ]);

    return successResponse(
      res,
      {
        appointments,
        pagination: {
          page: parsedPage,
          limit: parsedLimit,
          totalAppointments,
          totalPages: Math.ceil(totalAppointments / parsedLimit),
          hasNextPage: parsedPage * parsedLimit < totalAppointments,
          hasPreviousPage: parsedPage > 1,
        },
      },
      "Appointments retrieved successfully.",
      "Get appointments successful.",
    );
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.");
  }
};

export const getDailyScheduleWithAppointments = async (req, res) => {
  const { userId } = req.params;
  const { date } = req.body;

  const formattedDate = normalizeDate(date);

  if (!formattedDate) {
    return res.status(400).json({
      success: false,
      message: "Invalid date format.",
    });
  }

  const day = new Date(date).getDay();
  const dayNumber = Number(day);
  const dayKey = DayMap[dayNumber];

  if (!dayKey) {
    return res.status(400).json({
      success: false,
      message: "Invalid day",
    });
  }

  try {
    const [exceptionalDay, weeklySchedule, dailyAppointments] = await Promise.all([
      ExceptionalDays.findOne({
        doctorUserId: userId,
        date: formattedDate,
      }),
      WeeklyDays.findOne({ doctorUserId: userId }, { [dayKey]: 1, doctorUserId: 1 }),
      Appointment.find({
        doctorUserId: userId,
        appointmentDate: formattedDate,
      }),
    ]);

    const dailySchedule = exceptionalDay ? [] : weeklySchedule?.[dayKey] ? [weeklySchedule[dayKey]] : [];

    return successResponse(
      res,
      {
        dailySchedule,
        exceptionalDay: exceptionalDay ? [exceptionalDay] : [],
        dailyAppointments,
      },
      "Schedule and appointments fetched successfully.",
      "Schedule and appointments fetched successfully.",
    );
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Failed to fetch schedule and appointments");
  }
};

export const getTotalCommentsPatients = async (req, res) => {
  const { userId } = req.params;
  try {
    let totalComments = await Comment.countDocuments({ userId: userId });
    totalComments = formatQuantityNumber(totalComments);
    let totalAppointments = await Appointment.countDocuments({ doctorUserId: userId, status: "completed" });
    totalAppointments = formatQuantityNumber(totalAppointments);

    return successResponse(res, { totalComments, totalAppointments }, "Total comments fetched successfully.", "Total comments fetched successfully.");
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.");
  }
};

export const addDoctorWeeklySchedule = async (req, res) => {
  try {
    const { mon, tue, wed, thu, fri, sat, sun } = req.body;
    console.log("🚀 ~ doctorRegistration.js:1264 ~ addDoctorWeeklySchedule ~ fri:", fri);
    const { userId: doctorUserId } = req.params;

    if (!doctorUserId) {
      return res.status(400).json({
        success: false,
        message: "doctorUserId is required in request body.",
      });
    }

    const dayNames = {
      mon: "Monday",
      tue: "Tuesday",
      wed: "Wednesday",
      thu: "Thursday",
      fri: "Friday",
      sat: "Saturday",
      sun: "Sunday",
    };

    const DAYS = { mon, tue, wed, thu, fri, sat, sun };

    // ── Helper: convert "HH:MM" to total minutes ──
    const toMinutes = (timeStr) => {
      const [h, m] = timeStr.split(":").map(Number);
      return h * 60 + m;
    };

    // ── Validate all day slots ──
    for (const [dayKey, dayVal] of Object.entries(DAYS)) {
      if (!dayVal) continue; // day not provided — skip

      const { time = [] } = dayVal;

      for (let i = 0; i < time.length; i++) {
        const slot = time[i];
        const { startTime, endTime, maxAppointments } = slot;

        // Required fields
        if (!startTime || !endTime) {
          return res.status(400).json({
            success: false,
            message: `On ${dayNames[dayKey]}, the end time must be later than the start time.`,
          });
        }

        // 24h format check: HH:MM
        const timeRegex = /^([01]\d|2[0-3]):([0-5]\d)$/;
        if (!timeRegex.test(startTime)) {
          return res.status(400).json({
            success: false,
            message: `${dayKey} slot[${i}]: startTime "${startTime}" is not valid 24h format (HH:MM).`,
          });
        }
        if (!timeRegex.test(endTime)) {
          return res.status(400).json({
            success: false,
            message: `${dayKey} slot[${i}]: endTime "${endTime}" is not valid 24h format (HH:MM).`,
          });
        }

        // endTime must be AFTER startTime
        if (toMinutes(endTime) <= toMinutes(startTime)) {
          return res.status(400).json({
            success: false,
            message: `Invalid schedule for ${dayNames[dayKey]}. The end time (${endTime}) must be later than the start time (${startTime}).`,
          });
        }

        // maxAppointments must be a positive number
        if (maxAppointments && maxAppointments < 1) {
          return res.status(400).json({
            success: false,
            message: `${dayKey} slot[${i}]: maxAppointments must be a positive number.`,
          });
        }
      }
    }

    // ── Check if doc already exists ──
    const existingDoc = await WeeklyDays.findOne({ doctorUserId });

    // ── Build the update payload (only override days that were sent) ──
    const updatePayload = {};
    for (const [dayKey, dayVal] of Object.entries(DAYS)) {
      if (dayVal !== undefined) {
        updatePayload[dayKey] = dayVal;
      }
    }

    let savedDoc;

    if (existingDoc) {
      // Update existing doc
      Object.assign(existingDoc, updatePayload);
      savedDoc = await existingDoc.save();
    } else {
      // Create new doc
      savedDoc = await WeeklyDays.create({
        doctorUserId,
        ...updatePayload,
      });
    }

    return res.status(200).json({
      success: true,
      message: existingDoc ? "Weekly schedule updated successfully." : "Weekly schedule created successfully.",
      data: savedDoc,
    });
  } catch (error) {
    console.error("addDoctorWeeklySchedule error:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error.",
      error: error.message,
    });
  }
};

export const getAllAppointmentsByAdmin = async (req, res) => {
  const {
    limit = 10,
    page = 1,
    filterBy, // "fullName" | "location" | "appointmentsCount"
    sortOrder = "asc",
    status = "all",
    search = "",
  } = req.body;

  try {
    const parsedLimit = Number(limit);
    const parsedPage = Number(page);
    const dir = sortOrder === "desc" ? -1 : 1;

    let sortStage = { appointmentsCount: -1 };

    switch (filterBy) {
      case "fullName":
        sortStage = { fullName: dir };
        break;

      case "location":
        sortStage = { currentWorkplace: dir };
        break;

      case "appointmentsCount":
        sortStage = { appointmentsCount: dir };
        break;

      default:
        sortStage = { appointmentsCount: -1 };
    }

    const appointmentLookupPipeline = [
      {
        $match: {
          $expr: { $eq: ["$doctorUserId", "$$doctorUserId"] },
        },
      },
    ];

    if (status !== "all") {
      appointmentLookupPipeline.push({ $match: { status } });
    }

    appointmentLookupPipeline.push(
      { $sort: { createdAt: -1 } },
      {
        $lookup: {
          from: "doctors",
          localField: "userId",
          foreignField: "userId",
          as: "patient",
        },
      },
      {
        $unwind: { path: "$patient", preserveNullAndEmptyArrays: true },
      },
      {
        $addFields: {
          patientName: "$patient.fullName",
          patientEmail: "$patient.email",
          patientPhone: "$patient.phoneNumber",
          patientProfilePhoto: "$patient.profilePhoto",
        },
      },
      { $project: { patient: 0 } },
    );

    // shared $match for the base User query (verified doctors + search)
    const baseMatch = {
      type: 1,
      isVerified: true,
    };

    if (search) {
      const re = new RegExp(search, "i");
      baseMatch.$or = [{ fullName: re }, { phoneNumber: re }, { currentWorkplace: re }];
    }

    const [doctors, totalDoctors] = await Promise.all([
      User.aggregate([
        { $match: baseMatch },

        {
          $lookup: {
            from: "appointments",
            let: { doctorUserId: "$userId" },
            pipeline: appointmentLookupPipeline,
            as: "appointments",
          },
        },

        {
          $addFields: {
            appointmentsCount: { $size: "$appointments" },
            latestAppointment: { $arrayElemAt: ["$appointments", 0] },
          },
        },

        {
          $addFields: {
            statusOrder: {
              $switch: {
                branches: [
                  { case: { $eq: ["$latestAppointment.status", "pending"] }, then: 1 },
                  { case: { $eq: ["$latestAppointment.status", "confirmed"] }, then: 2 },
                  { case: { $eq: ["$latestAppointment.status", "completed"] }, then: 3 },
                  { case: { $eq: ["$latestAppointment.status", "cancelled"] }, then: 4 },
                ],
                default: 5,
              },
            },
          },
        },

        { $match: { appointmentsCount: { $gt: 0 } } },

        { $sort: sortStage },

        {
          $project: {
            userId: 1,
            fullName: 1,
            profilePhoto: 1,
            doctorRegistrationNumber: 1,
            currentWorkplace: 1,
            appointmentsCount: 1,
            specialties: 1,
            location: 1,
            phoneNumber: 1,
            email: 1,
            isVerified: 1,
            doctorIdCard: 1,
            appointments: 1,
          },
        },

        { $skip: (parsedPage - 1) * parsedLimit },
        { $limit: parsedLimit },
      ]),

      User.aggregate([
        { $match: baseMatch },

        {
          $lookup: {
            from: "appointments",
            let: { doctorUserId: "$userId" },
            pipeline: [
              {
                $match: { $expr: { $eq: ["$doctorUserId", "$$doctorUserId"] } },
              },
              ...(status !== "all" ? [{ $match: { status } }] : []),
            ],
            as: "appointments",
          },
        },

        {
          $addFields: { appointmentsCount: { $size: "$appointments" } },
        },

        { $match: { appointmentsCount: { $gt: 0 } } },

        { $count: "total" },
      ]),
    ]);

    const total = totalDoctors[0]?.total || 0;

    if (!doctors.length) {
      return notFoundResponse(res, "No doctors with appointments found.", "Get appointments failed: empty result.");
    }

    return successResponse(
      res,
      {
        doctors,
        pagination: {
          page: parsedPage,
          limit: parsedLimit,
          total,
          totalPages: Math.ceil(total / parsedLimit),
        },
      },
      "Appointments retrieved successfully.",
      "Get appointments successful.",
    );
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.");
  }
};

export const confirmAppointmentByAdmin = async (req, res) => {
  const { id } = req.params;
  console.log("🚀 ~ doctorRegistration.js:1672 ~ confirmAppointmentByAdmin ~ id:", id);

  try {
    const appointment = await Appointment.findByIdAndUpdate(
      {
        _id: id,
        isDeleted: false,
        status: "pending",
      },
      {
        $set: {
          status: "confirmed",
        },
      },
      {
        new: true,
      },
    );

    if (!appointment) {
      return res.status(400).json({
        success: false,
        message: "Only pending appointments can be confirmed.",
      });
    }

    // Fetch doctor & patient
    const [patient, doctor] = await Promise.all([User.findOne({ userId: appointment.userId }).lean(), User.findOne({ userId: appointment.doctorUserId }).lean()]);

    const appointmentId = appointment._id.toString();

    if (patient && doctor) {
      await Promise.all([
        sendNotificationToUser({
          appointmentId,
          userId: patient.userId,
          title: "Appointment Confirmed",
          body: `Your appointment with Dr. ${doctor.fullName} has been confirmed for ${appointment.appointmentDate} from ${appointment.startTime} to ${appointment.endTime}.`,
          type: "patientAppointment",
          data: {
            appointmentId,
            doctorUserId: doctor.userId,
            doctorName: doctor.fullName,
            appointmentDate: appointment.appointmentDate,
            startTime: appointment.startTime,
            endTime: appointment.endTime,
          },
        }),

        sendNotificationToUser({
          appointmentId,
          userId: doctor.userId,
          title: "Appointment Confirmed",
          body: `Your appointment with ${patient.fullName} has been confirmed for ${appointment.appointmentDate} from ${appointment.startTime} to ${appointment.endTime}.`,
          type: "doctorAppointment",
          data: {
            appointmentId,
            patientUserId: patient.userId,
            patientName: patient.fullName,
            appointmentDate: appointment.appointmentDate,
            startTime: appointment.startTime,
            endTime: appointment.endTime,
          },
        }),

        // Save notification for patient
        Notification.create({
          appointmentId,
          userId: patient.userId.toString(),
          type: "patientAppointment",
          title: "Appointment Confirmed",
          body: `Your appointment with Dr. ${doctor.fullName} has been confirmed for ${appointment.appointmentDate} from ${appointment.startTime} to ${appointment.endTime}.`,
          notificationSendTime: getBDCurrentTime(),
          notificationSendDate: getBDCurrentDate(),
        }),

        // Save notification for doctor
        Notification.create({
          appointmentId,
          userId: doctor.userId.toString(),
          type: "doctorAppointment",
          title: "Appointment Confirmed",
          body: `Your appointment with ${patient.fullName} has been confirmed for ${appointment.appointmentDate} from ${appointment.startTime} to ${appointment.endTime}.`,
          notificationSendTime: getBDCurrentTime(),
          notificationSendDate: getBDCurrentDate(),
        }),
      ]);
    }

    const patientFCMTOkens = await UserFCMToken.findOne({ userId: patient.userId });

    const reminders = [];

    const [year, month, day] = appointment.appointmentDate.split("-").map(Number);

    // Appointment day
    const appointmentDate = new Date(year, month - 1, day);

    // 2 days before
    const twoDaysBefore = new Date(appointmentDate);
    twoDaysBefore.setDate(twoDaysBefore.getDate() - 2);

    // 1 day before
    const oneDayBefore = new Date(appointmentDate);
    oneDayBefore.setDate(oneDayBefore.getDate() - 1);

    const formatDate = (date) => {
      const yyyy = date.getFullYear();
      const mm = String(date.getMonth() + 1).padStart(2, "0");
      const dd = String(date.getDate()).padStart(2, "0");

      return `${yyyy}-${mm}-${dd}`;
    };

    // Reminder (2 days before)
    reminders.push({
      userId: patient.userId,
      fcmTokens: patientFCMTOkens.fcmTokens,
      notificationSendDate: formatDate(twoDaysBefore),
      notificationSendTime: patient.notificationPreferenceTime,
      title: "Appointment Reminder",
      body: `Reminder: You have an appointment with Dr. ${doctor.fullName} on ${appointment.appointmentDate} from ${appointment.startTime} to ${appointment.endTime}.`,
      type: "patientAppointment",
      isSent: false,
      autoReminderLimit: 1,
    });

    // 1 Day Before

    reminders.push({
      userId: patient.userId,
      fcmTokens: patientFCMTOkens?.fcmTokens || [],
      notificationSendDate: formatDate(oneDayBefore),
      notificationSendTime: patient.notificationPreferenceTime,
      title: "Appointment Reminder",
      body: `Reminder: Tomorrow you have an appointment with Dr. ${doctor.fullName} from ${appointment.startTime} to ${appointment.endTime}.`,
      type: "patientAppointment",
      isSent: false,
      autoReminderLimit: 1,
    });

    // Reminder (same day)
    reminders.push({
      userId: patient.userId,
      fcmTokens: patientFCMTOkens.fcmTokens,
      notificationSendDate: formatDate(appointmentDate),
      // notificationSendTime: patient.notificationPreferenceTime,
      //todo here im sending notification at 6 AM even though user have their own prefered time
      notificationSendTime: STATIC_TIME_FOR_SEND_NOTI_AT_TODAY,
      title: "Appointment Today",
      body: `Today you have an appointment with Dr. ${doctor.fullName} from ${appointment.startTime} to ${appointment.endTime}.`,
      type: "patientAppointment",
      isSent: false,
      autoReminderLimit: 1,
    });

    const result = await Notification.insertMany(reminders);

    return successResponse(res, appointment, "Appointment confirmed successfully.", "Appointment confirmed successfully.");
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.");
  }
};

export const cancelAppointmentByAdmin = async (req, res) => {
  const { id } = req.params;
  const { note } = req.body;

  try {
    const appointment = await Appointment.findOneAndUpdate(
      {
        _id: id,
        isDeleted: false,
      },
      {
        $set: {
          status: "cancelled",
          cancelledBy: "admin",
          note,
        },
      },
      {
        new: true,
      },
    );

    if (!appointment) {
      return res.status(400).json({
        success: false,
        message: "Appointment not found.",
      });
    }

    // Fetch patient & doctor
    const [patient, doctor] = await Promise.all([User.findOne({ userId: appointment.userId }).lean(), User.findOne({ userId: appointment.doctorUserId }).lean()]);
    const appointmentId = appointment._id.toString();
    if (patient && doctor) {
      await Promise.all([
        sendNotificationToUser({
          userId: patient.userId,
          title: "Appointment Cancelled",
          body: `Your appointment with Dr. ${doctor.fullName} on ${appointment.appointmentDate} from ${appointment.startTime} to ${appointment.endTime} has been cancelled by the administrator.${note ? ` Reason: ${note}` : ""}`,
          type: "doctorAppointment",
          appointmentId,
          data: {
            appointmentId: appointment._id,
            doctorUserId: doctor.userId,
            doctorName: doctor.fullName,
            appointmentDate: appointment.appointmentDate,
            startTime: appointment.startTime,
            endTime: appointment.endTime,
            note: note || "",
          },
        }),

        sendNotificationToUser({
          userId: doctor.userId,
          appointmentId,
          title: "Appointment Cancelled",
          body: `The appointment with ${patient.fullName} on ${appointment.appointmentDate} from ${appointment.startTime} to ${appointment.endTime} has been cancelled by the administrator.${note ? ` Reason: ${note}` : ""}`,
          type: "patientAppointment",
          data: {
            appointmentId: appointment._id,
            patientUserId: patient.userId,
            patientName: patient.fullName,
            appointmentDate: appointment.appointmentDate,
            startTime: appointment.startTime,
            endTime: appointment.endTime,
            note: note || "",
          },
        }),
      ]);
    }

    const noti1 = await saveNotificationToDB({
      userId: patient.userId.toString(),
      type: "patientAppointment",
      appointmentId,
      notificationSendTime: new Date().toISOString(),
      notificationSendDate: new Date().toISOString(),
      title: "Appointment Cancelled",
      body: `Your appointment with Dr. ${doctor.fullName} on ${appointment.appointmentDate} from ${appointment.startTime} to ${appointment.endTime} has been cancelled by the administrator.${note ? ` Reason: ${note}` : ""}`,
    });

    console.log("🚀 ~ doctorRegistration.js:1845 ~ cancelAppointmentByAdmin ~ noti1:", noti1);

    const noti2 = await saveNotificationToDB({
      userId: doctor.userId.toString(),
      type: "doctorAppointment",
      appointmentId,
      notificationSendTime: new Date().toISOString(),
      notificationSendDate: new Date().toISOString(),
      title: "Appointment Cancelled",
      body: `The appointment with ${patient.fullName} on ${appointment.appointmentDate} from ${appointment.startTime} to ${appointment.endTime} has been cancelled by the administrator.${note ? ` Reason: ${note}` : ""}`,
    });

    console.log("🚀 ~ doctorRegistration.js:1855 ~ cancelAppointmentByAdmin ~ noti2:", noti2);

    // Save notification for patient
    // Notification.create(),

    // Save notification for doctor
    // Notification.create(),

    return successResponse(res, appointment, "Appointment cancelled successfully.", "Appointment cancelled successfully.");
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.");
  }
};

export const loginByAdmin = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(200).json({
        success: false,
        message: "User not found.",
      });
    }

    if (user.type != 2) {
      return res.status(200).json({
        success: false,
        message: "Unauthorized user.",
      });
    }

    if (user.adminStatus && user.adminStatus === "pending") {
      return res.status(200).json({
        success: false,
        message: "Your request is pending now.",
      });
    }

    if (user.adminStatus && user.adminStatus === "suspended") {
      return res.status(200).json({
        success: false,
        message: "Your account is suspended now. Contact with an admin.",
      });
    }

    const isMatched = await bcrypt.compare(password, user.password);

    if (!isMatched) {
      return res.status(200).json({
        success: false,
        message: "Invalid credentials.",
      });
    }

    const token = generateToken(user);

    const routerJSON = await Role.findOne({ role: user.role });

    const routes = routerJSON?.routeJSON || "[]";

    return res
      .cookie("accessToken", token, {
        httpOnly: true,
        secure: ENV === "prod" ? true : false,
        sameSite:ENV === "prod" ? "none" : "lax", // or "lax"
        maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      })
      .status(200)
      .json({
        success: true,
        user: {
          id: user._id,
          email: user.email,
          type: user.type,
          routes: JSON.parse(routes),
        },
      });
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.");
  }
};

export const logoutAdmin = async (req, res) => {
  return res
    .clearCookie("accessToken", {
      httpOnly: true,
      secure: ENV === "prod",
      sameSite: "strict",
    })
    .status(200)
    .json({
      success: true,
      message: "Logged out successfully",
    });
};

export const signUpAsAdmin = async (req, res) => {
  const { fullName, email, password, role, phoneNumber } = req.body;

  try {
    const user = await User.findOne({ email });

    if (user) {
      if (user.adminStatus === "pending" && user.type === 2) {
        return res.status(200).json({
          success: false,
          message: "Your request is pending now.",
        });
      }

      if (user.adminStatus === "suspended" && user.type === 2) {
        return res.status(200).json({
          success: false,
          message: "Your are suspended from this panel. Please contact with other admin.",
        });
      }

      if (user.adminStatus === "active" && user.type === 2) {
        return res.status(200).json({
          success: false,
          message: "Your are suspended from this panel. Please contact with other admin.",
        });
      }

      if (user.email === email && user.type != 2) {
        return res.status(200).json({
          success: false,
          message: "Unauthorized user.",
        });
      }
    } else {
      const userId = generateUserId(2);

      const hashedPassword = await bcrypt.hash(password, 10);

      let profilePhoto = "";

      if (req.file) {
        const uploaded = await uploadToImageBB(req.file);

        if (uploaded) {
          profilePhoto = uploaded;
        }
      }

      const newUser = new User({
        email,
        password: hashedPassword,
        type: 2,
        fullName,
        userId,
        type: 2,
        profilePhoto: profilePhoto,
        role,
        phoneNumber,
        adminStatus: "pending",
      });

      const result = await newUser.save();

      const token = generateToken(newUser);

      return res.status(201).json({
        success: true,
        user: {
          id: result._id,
          email: result.email,
          type: result.type,
        },
        message: "New admin user created successfully.",
      });
    }
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.");
  }
};

export const updateAdminPassword = async (req, res) => {
  const { password } = req.body;

  try {
    const user = await User.findOne({ userId: req.params.userId });

    if (user.type !== 2) {
      return res.status(403).json({
        success: false,
        message: "Unauthorized.",
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    user.password = hashedPassword;

    await user.save();

    return res.status(200).json({
      success: true,
      message: "Admin password updated successfully.",
    });
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.");
  }
};

export const suspendUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findOne({ userId });
    if (user.type !== 2) {
      return res.status(403).json({
        success: false,
        message: "Unauthorized.",
      });
    }
    if (user.adminStatus !== "active") {
      return badRequestResponse(res, "Unable to suspend user.", "User is already suspended.");
    } else {
      user.adminStatus = "suspended";
      await user.save();
      return successResponse(res, user, "User suspended successfully.", "User suspended successfully.");
    }
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.", "Something went wrong.");
  }
};

export const activateUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findOne({ userId });
    if (user.type !== 2) {
      return res.status(403).json({
        success: false,
        message: "Unauthorized user.",
      });
    }
    if (user.adminStatus !== "suspended" && user.adminStatus !== "pending") {
      return badRequestResponse(res, "Unable to active user.", "User is already active.");
    } else {
      user.adminStatus = "active";
      await user.save();
      return successResponse(res, user, "User activated successfully.", "User active successfully.");
    }
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.", "Something went wrong.");
  }
};

export const deleteUser = async (req, res) => {
  try {
    const { userId } = req.params;

    const user = await User.findOneAndDelete({
      userId,
      type: 2,
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found.",
      });
    }

    return successResponse(res, user, "User deleted successfully.", "User deleted successfully.");
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.", "Something went wrong.");
  }
};

export const getAllAdminUsers = async (req, res) => {
  try {
    const { role, limit, page, sortBy, sortOrder } = req.body;

    const skip = (page - 1) * limit;

    const filter = { type: 2, isRemoved: false };

    if (role) {
      filter.role = role;
    }

    const count = await User.countDocuments(filter);

    const users = await User.find(filter)
      .select("userId profilePhoto fullName email phoneNumber adminStatus createdAt role")
      .sort({ [sortBy]: sortOrder })
      .skip(skip)
      .limit(limit);

    return paginatedSuccessResponse(res, users, page, limit, count, "Admin users retrieved successfully", "Get all admin users successfully.");
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.");
  }
};

export const updateRoleByAdmin = async (req, res) => {
  try {
    const { userId } = req.params;
    const { role } = req.body;

    const allowedRoles = ["admin", "superadmin", "communitymodarator", "appointmentmanager", "doctormanager"];

    const user = await User.findOne({ userId });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found.",
      });
    }

    if (user.type !== 2) {
      return res.status(403).json({
        success: false,
        message: "Unauthorized.",
      });
    }

    if (!allowedRoles.includes(role)) {
      return res.status(400).json({
        success: false,
        message: "Invalid role.",
      });
    }

    user.role = role;
    await user.save();

    return successResponse(res, user, "Role updated successfully.", "Role updated successfully.");
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Something went wrong.");
  }
};

export const getDoctorDetailsWithSchedule = async (req, res) => {
  const { userId } = req.params;
  let { month } = req.body;
  month = Number(req.body.month);

  try {
    if (!MonthMap[month]) {
      return badRequestResponse(res, "Invalid month", "Month must be between 1 and 12");
    }

    const weekDay = await WeeklyDays.findOne({
      doctorUserId: userId,
    });

    const exceptionalDay = await ExceptionalDays.find({
      doctorUserId: userId,
    });

    const filteredExceptionalDays = exceptionalDay.filter((item) => {
      return new Date(item.date).getMonth() + 1 === month;
    });

    const doctorDetails = await User.findOne({ userId });

    return successResponse(
      res,
      {
        doctorDetails,
        weekDay,
        exceptionalDay: filteredExceptionalDays,
      },
      "Schedule fetched successfully",
      "Schedule fetched successfully",
    );
  } catch (error) {
    console.error(error);
    return somethingWentWrong(res, error, "Failed to fetch schedule");
  }
};

export const getAllNotificationsToAll = async (req, res) => {
  try {
    const { userId } = req.params;

    const user = await User.findOne({ userId }).select("type");

    if (!user) {
      return notFoundResponse(res, "User not found", "User not found");
    }

    let notificationTypes = [];

    if (user.type === 0) {
      // Patient
      notificationTypes = ["patientAppointment", "post"];
    } else if (user.type === 1) {
      // Doctor
      notificationTypes = ["doctorAppointment", "post", "accountVerified"];
    }

    const notifications = await Notification.find({
      userId,
      type: { $in: notificationTypes },
    }).sort({ createdAt: -1 });
    console.log("🚀 ~ doctorRegistration.js:2398 ~ getAllNotificationsToAll ~ notifications:", notifications);

    return successResponse(res, notifications, "Notifications fetched successfully", "Notifications fetched successfully");
  } catch (error) {
    return somethingWentWrong(res, error, "Failed to fetch notifications", "Failed to fetch notifications");
  }
};

export const markNotificationAsRead = async (req, res) => {
  try {
    const { userId } = req.params;

    // Current Bangladesh time
    const now = new Date();

    const bdCurrentTime = new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Dhaka",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    }).format(now);

    // Format: YYYY-MM-DD HH:mm
    const currentDateTime = bdCurrentTime.replace(",", "");

    const notifications = await Notification.find({
      userId,
      isRead: false,
    });

    const notificationIds = notifications
      .filter((notification) => {
        const notificationDateTime = `${notification.notificationSendDate} ${notification.notificationSendTime}`;
        return notificationDateTime <= currentDateTime;
      })
      .map((notification) => notification._id);

    const result = await Notification.updateMany(
      {
        _id: { $in: notificationIds },
      },
      {
        $set: {
          isRead: true,
        },
      },
    );

    return successResponse(
      res,
      {
        matchedCount: result.matchedCount,
        modifiedCount: result.modifiedCount,
      },
      "Notifications marked as read successfully.",
      "Notifications marked as read successfully.",
    );
  } catch (error) {
    return somethingWentWrong(res, error, "Failed to mark notifications as read.", "Failed to mark notifications as read.");
  }
};

// export const getDoctorUpcomingAppointments = async (req, res) => {
//   try {
//     const { userId } = req.params;

//     const { date, page = 1, limit = 10, search = "" } = req.body;

//     const parsedPage = Math.max(parseInt(page), 1);
//     const parsedLimit = Math.max(parseInt(limit), 1);

//     // Base filter
//     const appointmentFilter = {
//       doctorUserId: userId,
//       appointmentDate: date,
//       isDeleted: false,
//       status: "confirmed",
//     };

//     // Fetch all appointments for that date
//     const appointments = await Appointment.find(appointmentFilter).lean();

//     if (!appointments.length) {
//       return successResponse(
//         res,
//         {
//           appointments: [],
//           pagination: {
//             page: parsedPage,
//             limit: parsedLimit,
//             totalAppointments: 0,
//             totalPages: 0,
//             hasNextPage: false,
//             hasPreviousPage: false,
//           },
//         },
//         "No appointments found.",
//         "Appointments fetched successfully.",
//       );
//     }

//     // Collect all patient ids
//     const patientIds = [...new Set(appointments.map((a) => a.userId))];

//     // Fetch all patients in one query
//     const users = await User.find({
//       userId: { $in: patientIds },
//     }).lean();

//     const userMap = {};

//     users.forEach((user) => {
//       userMap[user.userId] = user;
//     });

//     // Attach patient info
//     let mergedAppointments = appointments.map((appointment) => ({
//       ...appointment,
//       patient: userMap[appointment.userId] || null,
//     }));

//     // Search
//     if (search.trim()) {
//       const keyword = search.toLowerCase();

//       mergedAppointments = mergedAppointments.filter((item) => {
//         const patient = item.patient;

//         if (!patient) return false;

//         return patient.fullName?.toLowerCase().includes(keyword) || patient.email?.toLowerCase().includes(keyword) || patient.phoneNumber?.toLowerCase().includes(keyword) || patient.userId?.toLowerCase().includes(keyword);
//       });
//     }

//     // Sort by start time
//     mergedAppointments.sort((a, b) => a.startTime.localeCompare(b.startTime));

//     // Pagination
//     const totalAppointments = mergedAppointments.length;

//     const paginatedAppointments = mergedAppointments.slice((parsedPage - 1) * parsedLimit, parsedPage * parsedLimit);

//     return successResponse(
//       res,
//       {
//         appointments: paginatedAppointments,
//         pagination: {
//           page: parsedPage,
//           limit: parsedLimit,
//           totalAppointments,
//           totalPages: Math.ceil(totalAppointments / parsedLimit),
//           hasNextPage: parsedPage * parsedLimit < totalAppointments,
//           hasPreviousPage: parsedPage > 1,
//         },
//       },
//       "Appointments fetched successfully.",
//       "Appointments fetched successfully.",
//     );
//   } catch (error) {
//     console.error(error);

//     return somethingWentWrong(res, error, "Failed to fetch appointments", "Failed to fetch appointments");
//   }
// };



export const getDoctorUpcomingAppointments = async (req, res) => {
  try {
    const { userId } = req.params;

    const appointments = await Appointment.find({
      doctorUserId: userId,
      isDeleted: false,
      status: "confirmed",
    })
      .sort({ appointmentDate: 1, startTime: 1 })
      .lean();

    if (!appointments.length) {
      return successResponse(
        res,
        [],
        "No appointments found.",
        "Appointments fetched successfully.",
      );
    }

    const patientIds = [...new Set(appointments.map((a) => a.userId))];

    const users = await User.find({
      userId: { $in: patientIds },
    }).lean();

    const userMap = {};

    users.forEach((user) => {
      userMap[user.userId] = user;
    });

    const mergedAppointments = appointments.map((appointment) => ({
      ...appointment,
      patient: userMap[appointment.userId] || null,
    }));

    return successResponse(
      res,
      mergedAppointments,
      "Appointments fetched successfully.",
      "Appointments fetched successfully.",
    );
  } catch (error) {
    console.error(error);

    return somethingWentWrong(
      res,
      error,
      "Failed to fetch appointments",
      "Failed to fetch appointments",
    );
  }
};